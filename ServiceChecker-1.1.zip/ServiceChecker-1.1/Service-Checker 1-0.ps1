﻿<#
.Synopsis
   This script monitors services on different servers the same environment.
.DESCRIPTION
   This script monitors services on different servers the same environment.
   To make this script work, you need too change some strings.
    . $SmtpServer = "Your SMTP"
    . $MailFrom = "Your Mailbox" 
    . $Mailto = "TeamMailBox" 

    . $Server1 = "Server1.FQDN"
    . $Server2 = "Server2.FQDN"
    . $Server3 = "Server3.FQDN"

    . $Service1 = "ServiceName"
    . $Service2 = "ServiceName"
    . $Service3 = "ServiceName"


.EXAMPLE
   Run in shell or add to task-scheduler with elevated rights
   Start a Program : C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe
   Arguments : -File "FilePathToScript\Service-Checker 1-0.ps1" -NoLogo -NoProfile -WindowStyle Hidden
.OUTPUTS
   Script saves
   Logs : $LogPath
   Services Csv file : $PSScriptRoot\Csv\*
.NOTES
   Script uses Invoke-Command, the inviroment must allow ps-sessions. For more information
   https://docs.microsoft.com/en-us/powershell/module/microsoft.powershell.core/invoke-command?view=powershell-7.1

.FUNCTIONALITY
   Monitoring services

.LINKS
   Github : https://github.com/fardinbarashi
   Source Code : https://github.com/fardinbarashi/ServiceChecker-1.0 
   Linkedin : https://www.linkedin.com/in/fardin-barashi-a56310a2/
   Mail : Fardin.barashi@gmail.com
#>

################################################################################################
#                                    SMTP Settings                                             # 
################################################################################################
$SmtpServer = "smtprelay.Lab.local"
$MailFrom = "ServiceChecker@Lab.local" 
$Mailto = "Functionalmailbox <Functionalmailbox@Lab.local>" 

################################################################################################
#                                    File-Path Settings                                        # 
################################################################################################ 


################################################################################################
#                                    Servers                                                   # 
################################################################################################ 
$Server1 = "Server1.Lab.local"
$Server2 = "Server2.Lab.local"
$Server3 = "Server3.Lab.local"

################################################################################################
#                                    Monitor Services                                          # 
################################################################################################ 
$Service1 = "Bits"
$Service2 = "Bits"
$Service3 = "Bits"


################################################################################################
#                                    FilePath                                                  # 
################################################################################################ 
# TranScript Logs
$LogPath = "$PSScriptRoot\Logs\Transcriptlog.txt" 

# Csv
$CsvServer1 = "$PSScriptRoot\Csv\Servers\Server 1\ServicesFromServer1.csv"
$CsvServer2 = "$PSScriptRoot\Csv\Servers\Server 2\ServicesFromServer2.csv"
$CsvServer3 = "$PSScriptRoot\Csv\Servers\Server 3\ServicesFromServer3.csv"

$MergedCsv =  "$PSScriptRoot\Csv\MergedCsv\MergedCsv.csv" 
################################################################################################
#                                    FunctionList                                              #  
################################################################################################
 # Server1 
   Function GetServicesServer1
    { # Start GetServicesServer1
     $GetServicesServer1 = ( @{ Computername="$Server1"; ServiceName="$Service1"})
     $GetServicesServer1 | %{ # Get  service Name & Status
     Get-Service -Computername $_.Computername -ServiceName $_.ServiceName } |
     Select-Object Name, Status |  Add-Member -MemberType NoteProperty -Name Server -Value $Server1 -PassThru |
     Export-Csv -Path $CsvServer1 -Force -NoTypeInformation 
    } # End GetServicesServer1

 # Server2 
   Function GetServicesServer2
    { # Start GetServicesServer2
     $GetServicesServer2 = ( @{ Computername="$Server2"; ServiceName="$Service2"})
     $GetServicesServer2 | %{ # Get  service Name & Status
     Get-Service -Computername $_.Computername -ServiceName $_.ServiceName } |
     Select-Object Name, Status |  Add-Member -MemberType NoteProperty -Name Server -Value $Server2 -PassThru |
     Export-Csv -Path $CsvServer2 -Force -NoTypeInformation 
    } # End GetServicesServer2

 # Server3 
   Function GetServicesServer3
    { # Start GetServicesServer3
     $GetServicesServer3 = ( @{ Computername="$Server3"; ServiceName="$Service3"})
     $GetServicesServer3 | %{ # Get  service Name & Status
     Get-Service -Computername $_.Computername -ServiceName $_.ServiceName } |
     Select-Object Name, Status |  Add-Member -MemberType NoteProperty -Name Server -Value $Server3 -PassThru |
     Export-Csv -Path $CsvServer3 -Force -NoTypeInformation 
    } # End GetServicesServer2

################################################################################################
#                                    Start-Script                                              # 
################################################################################################ 
Start-Transcript -Path $LogPath -Force -Append
Get-Date

# Remove Previous Csv-Files
$FileCsvServer1 = Get-ChildItem -Path $CsvServer1 -Recurse -Force | Test-Path -PathType Leaf
 If( $FileCsvServer1 -Eq $Null )
  {
   # $FileCsvServer1 Is Empty
  } 
 Else 
  {
   Write-host "Removing Previous $CsvServer1" -ForegroundColor Magenta
   Get-ChildItem -Path $CsvServer1 -Force -Recurse | Remove-Item -Force
  }

$FileCsvServer2 = Get-ChildItem -Path $CsvServer2 -Recurse -Force | Test-Path -PathType Leaf
 If( $FileCsvServer2 -Eq $Null )
  {
   # $FileCsvServer2 Is Empty
  } 
 Else 
  {
   Write-host "Removing Previous $CsvServer2" -ForegroundColor Magenta
   Get-ChildItem -Path $CsvServer2 -Force -Recurse | Remove-Item -Force
  }

$FileCsvServer3 = Get-ChildItem -Path $CsvServer3 -Recurse -Force | Test-Path -PathType Leaf
 If( $FileCsvServer3 -Eq $Null )
  {
   # $FileCsvServer3 Is Empty
  } 
 Else 
  {
   Write-host "Removing Previous $CsvServer3" -ForegroundColor Magenta
   Get-ChildItem -Path $CsvServer3 -Force -Recurse | Remove-Item -Force
  }

$FileMergedCsv = Get-ChildItem -Path $MergedCsv -Recurse -Force | Test-Path -PathType Leaf
 If( $FileMergedCsv -Eq $Null )
  {
   # $FileMergedCsv Is Empty
  } 
 Else 
  {
   Write-host "Removing Previous $MergedCsv" -ForegroundColor Magenta
   Get-ChildItem -Path $MergedCsv -Force -Recurse | Remove-Item -Force
  }
################################################################################################
#                                    Generate Service-Csv Files                                # 
################################################################################################ 

# GetServicesServer1   
 Try
  { # Start Try, GetServicesServer1
   GetServicesServer1
  } # End Try, GetServicesServer1
     
 Catch
  { # Start Catch, GetServicesServer1
   Get-Date

   $CustomErrorMessage= "The creation of the Service-Csv file has become incorrect, this applies $Server1 "
   $CustomErrorCodeMessage = "For more information, Check $LogPath"       

   Write-Warning -Message $CustomErrorMessage
   Write-Warning -Message $CustomErrorCodeMessage
   Write-Warning $Error[0]
  
   Stop-Transcript
     
   $MailSubject = " Creation of the Service-Csv : $Server1 "
   $MailBody = " $CustomErrorMessage, $CustomErrorCodeMessage"    
   Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer -Encoding ([System.Text.Encoding]::UTF8)         
  } # End Catch, GetServicesServer1
# GetServicesServer1   
 
# GetServicesServer2   
 Try
  { # Start Try, GetServicesServer2
   GetServicesServer2
  } # End Try, GetServicesServer2
     
 Catch
  { # Start Catch, GetServicesServer2
   Get-Date

   $CustomErrorMessage= "The creation of the Service-Csv file has become incorrect, this applies $Server2 "
   $CustomErrorCodeMessage = "For more information, Check $LogPath"       

   Write-Warning -Message $CustomErrorMessage
   Write-Warning -Message $CustomErrorCodeMessage
   Write-Warning $Error[0]
  
   Stop-Transcript
     
   $MailSubject = " Creation of the Service-Csv : $Server2 "
   $MailBody = " $CustomErrorMessage, $CustomErrorCodeMessage"    
   Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer -Encoding ([System.Text.Encoding]::UTF8)         
  } # End Catch, GetServicesServer2
# GetServicesServer2         

# GetServicesServer3   
 Try
  { # Start Try, GetServicesServer3
   GetServicesServer3
  } # End Try, GetServicesServer3
     
 Catch
  { # Start Catch, GetServicesServer3
   Get-Date

   $CustomErrorMessage= "The creation of the Service-Csv file has become incorrect, this applies $Server3 "
   $CustomErrorCodeMessage = "For more information, Check $LogPath"       

   Write-Warning -Message $CustomErrorMessage
   Write-Warning -Message $CustomErrorCodeMessage
   Write-Warning $Error[0]
  
   Stop-Transcript
     
   $MailSubject = " Creation of the Service-Csv : $Server3 "
   $MailBody = " $CustomErrorMessage, $CustomErrorCodeMessage"    
   Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer -Encoding ([System.Text.Encoding]::UTF8)         
  } # End Catch, GetServicesServer3
# GetServicesServer3

################################################################################################
#                                    Merge Service-Csv Files                                   # 
################################################################################################ 

 Try
  { # Start Try, Import Csv files, create a merged csv file
    $GetCsvFiles = Get-ChildItem -Path "$PSScriptRoot\Csv\Servers\" -Recurse -Filter "*.Csv" | 
    Select-Object -ExpandProperty FullName | Import-Csv | Export-Csv $MergedCsv -NoTypeInformation -Append -Encoding UTF8
  } # End Try, Import Csv files, create a merged csv file
     
 Catch
  { # Start Catch, Import Csv files, create a merged csv file
   Get-Date

   $CustomErrorMessage= "Merging Service-Csv files has stopped with errors"
   $CustomErrorCodeMessage = "For more information, Check $LogPath"       

   Write-Warning -Message $CustomErrorMessage
   Write-Warning -Message $CustomErrorCodeMessage
   Write-Warning $Error[0]
  
   Stop-Transcript
     
   $MailSubject = "Merging Service-Csv files has stopped with errors"
   $MailBody = " $CustomErrorMessage, $CustomErrorCodeMessage"    
   Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer -Encoding ([System.Text.Encoding]::UTF8)         
  } # End Catch, Import Csv files, create a merged csv file


################################################################################################
#                                    Restart Stopped Services                                  # 
################################################################################################ 

 Try
  { # Start Try, Restart Stopped Services
   $ImportMergedCsv = Import-Csv $MergedCsv -delimiter ',' -Encoding UTF8 | 
    ForEach 
     { # Start ForEach
      New-Object PSObject -Prop @{ # Start New PsObject
       #New Object -  Csv Column
       Servername = $_.Server;
       Servicename = $_.Name;
       ServiceStatus = $_.Status; 
      } # End New PsObject
     } # End ForEach       
    
   $CheckImportMergedCsv = $ImportMergedCsv | 
    Where-Object { $_.ServiceStatus -Match "Stopped" }  
     If( $CheckImportMergedCsv -Eq $Null ) 
      { # Start If 
       # Services are running 
      } # End If
     
     Else 
      { # Start Else
       $MailSubject = " ServiceChecker Restarting Services"
       $MailBody = "One of the critical services that had to be restarted. See log file $LogPath for more info"    
       Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer -Encoding ([System.Text.Encoding]::UTF8)         
          
       $RestartServices = Import-CSV $MergedCsv -delimiter ',' -Encoding UTF8
       ForEach ($Server in $RestartServices) 
        { # Start ForEach ($Server in $RestartServices) 
         # Restart Service
         Invoke-Command -ScriptBlock { Start-Service $args[0] } -ComputerName $Server.Server -ArgumentList $Server.Name.Split(",") 
        } # End # Start ForEach ($Server in $RestartServices)          
      } # End Else       
  } # End Try,  Restart Stopped Services
     
 Catch
  { # Start Catch, Restart Stopped Services
   Get-Date

   $CustomErrorMessage= "The process to restart services has stopped with errors"
   $CustomErrorCodeMessage = "For more information, Check $LogPath"       

   Write-Warning -Message $CustomErrorMessage
   Write-Warning -Message $CustomErrorCodeMessage
   Write-Warning $Error[0]
  
   Stop-Transcript
     
   $MailSubject = " The process to restart services has stopped with errors "
   $MailBody = " $CustomErrorMessage, $CustomErrorCodeMessage"    
   Send-MailMessage -To $Mailto -from "$MailFrom" -Subject $MailSubject -Body $MailBody -SmtpServer $SmtpServer -Encoding ([System.Text.Encoding]::UTF8)         
  } # End Catch, Restart Stopped Services

################################################################################################
#                                    End-Script                                               # 
################################################################################################ 
Stop-Transcript
